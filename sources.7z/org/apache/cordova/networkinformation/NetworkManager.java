package org.apache.cordova.networkinformation;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import java.util.Locale;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.LOG;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;

public class NetworkManager extends CordovaPlugin {
    public static final String CDMA = "cdma";
    public static final String CELLULAR = "cellular";
    public static final String EDGE = "edge";
    public static final String EHRPD = "ehrpd";
    public static final String FOUR_G = "4g";
    public static final String GPRS = "gprs";
    public static final String GSM = "gsm";
    public static final String HSDPA = "hsdpa";
    public static final String HSPA = "hspa";
    public static final String HSPA_PLUS = "hspa+";
    public static final String HSUPA = "hsupa";
    private static final String LOG_TAG = "NetworkManager";
    public static final String LTE = "lte";
    public static final String MOBILE = "mobile";
    public static int NOT_REACHABLE = 0;
    public static final String ONEXRTT = "1xrtt";
    public static int REACHABLE_VIA_CARRIER_DATA_NETWORK = 1;
    public static int REACHABLE_VIA_WIFI_NETWORK = 2;
    public static final String THREE_G = "3g";
    public static final String TWO_G = "2g";
    public static final String TYPE_2G = "2g";
    public static final String TYPE_3G = "3g";
    public static final String TYPE_4G = "4g";
    public static final String TYPE_ETHERNET = "ethernet";
    public static final String TYPE_ETHERNET_SHORT = "eth";
    public static final String TYPE_NONE = "none";
    public static final String TYPE_UNKNOWN = "unknown";
    public static final String TYPE_WIFI = "wifi";
    public static final String UMB = "umb";
    public static final String UMTS = "umts";
    public static final String WIFI = "wifi";
    public static final String WIMAX = "wimax";
    private CallbackContext connectionCallbackContext;
    /* access modifiers changed from: private */
    public String lastTypeOfNetwork;
    BroadcastReceiver receiver;
    ConnectivityManager sockMan;

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.sockMan = (ConnectivityManager) cordova.getActivity().getSystemService("connectivity");
        this.connectionCallbackContext = null;
        registerConnectivityActionReceiver();
    }

    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) {
        if (!action.equals("getConnectionInfo")) {
            return false;
        }
        this.connectionCallbackContext = callbackContext;
        PluginResult pluginResult = new PluginResult(PluginResult.Status.OK, getTypeOfNetworkFallbackToTypeNoneIfNotConnected(this.sockMan.getActiveNetworkInfo()));
        pluginResult.setKeepCallback(true);
        callbackContext.sendPluginResult(pluginResult);
        return true;
    }

    public void onDestroy() {
        unregisterReceiver();
    }

    public void onPause(boolean multitasking) {
        unregisterReceiver();
    }

    public void onResume(boolean multitasking) {
        super.onResume(multitasking);
        unregisterReceiver();
        registerConnectivityActionReceiver();
    }

    private void registerConnectivityActionReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        if (this.receiver == null) {
            this.receiver = new BroadcastReceiver() {
                public void onReceive(Context context, Intent intent) {
                    String connectionType;
                    if (NetworkManager.this.webView != null) {
                        NetworkManager networkManager = NetworkManager.this;
                        networkManager.updateConnectionInfo(networkManager.sockMan.getActiveNetworkInfo());
                    }
                    if (NetworkManager.this.lastTypeOfNetwork == null) {
                        connectionType = NetworkManager.TYPE_NONE;
                    } else {
                        connectionType = NetworkManager.this.lastTypeOfNetwork;
                    }
                    if (Build.VERSION.SDK_INT >= 23 && NetworkManager.TYPE_NONE.equals(connectionType)) {
                        boolean noConnectivity = intent.getBooleanExtra("noConnectivity", false);
                        LOG.d(NetworkManager.LOG_TAG, "Intent no connectivity: " + noConnectivity);
                        if (noConnectivity) {
                            LOG.d(NetworkManager.LOG_TAG, "Really no connectivity");
                            return;
                        }
                        LOG.d(NetworkManager.LOG_TAG, "!!! Switching to unknown, Intent states there is a connectivity.");
                        NetworkManager.this.sendUpdate(NetworkManager.TYPE_UNKNOWN);
                    }
                }
            };
        }
        this.webView.getContext().registerReceiver(this.receiver, intentFilter);
    }

    private void unregisterReceiver() {
        if (this.receiver != null) {
            try {
                this.webView.getContext().unregisterReceiver(this.receiver);
            } catch (Exception e) {
                LOG.e(LOG_TAG, "Error unregistering network receiver: " + e.getMessage(), (Throwable) e);
            } catch (Throwable th) {
                this.receiver = null;
                throw th;
            }
            this.receiver = null;
        }
    }

    /* access modifiers changed from: private */
    public void updateConnectionInfo(NetworkInfo info) {
        String currentNetworkType = getTypeOfNetworkFallbackToTypeNoneIfNotConnected(info);
        if (currentNetworkType.equals(this.lastTypeOfNetwork)) {
            LOG.d(LOG_TAG, "Networkinfo state didn't change, there is no event propagated to the JavaScript side.");
            return;
        }
        sendUpdate(currentNetworkType);
        this.lastTypeOfNetwork = currentNetworkType;
    }

    private String getTypeOfNetworkFallbackToTypeNoneIfNotConnected(NetworkInfo info) {
        String type;
        if (info == null) {
            type = TYPE_NONE;
        } else if (!info.isConnected()) {
            type = TYPE_NONE;
        } else {
            type = getType(info);
        }
        LOG.d(LOG_TAG, "Connection Type: " + type);
        return type;
    }

    /* access modifiers changed from: private */
    public void sendUpdate(String type) {
        if (this.connectionCallbackContext != null) {
            PluginResult result = new PluginResult(PluginResult.Status.OK, type);
            result.setKeepCallback(true);
            this.connectionCallbackContext.sendPluginResult(result);
        }
        this.webView.postMessage("networkconnection", type);
    }

    private String getType(NetworkInfo info) {
        String type = info.getTypeName().toLowerCase(Locale.US);
        LOG.d(LOG_TAG, "toLower : " + type);
        if (type.equals("wifi")) {
            return "wifi";
        }
        if (type.toLowerCase().equals(TYPE_ETHERNET) || type.toLowerCase().startsWith(TYPE_ETHERNET_SHORT)) {
            return TYPE_ETHERNET;
        }
        if (!type.equals(MOBILE) && !type.equals(CELLULAR)) {
            return TYPE_UNKNOWN;
        }
        String type2 = info.getSubtypeName().toLowerCase(Locale.US);
        if (type2.equals(GSM) || type2.equals(GPRS) || type2.equals(EDGE) || type2.equals("2g")) {
            return "2g";
        }
        if (type2.startsWith(CDMA) || type2.equals(UMTS) || type2.equals(ONEXRTT) || type2.equals(EHRPD) || type2.equals(HSUPA) || type2.equals(HSDPA) || type2.equals(HSPA) || type2.equals("3g")) {
            return "3g";
        }
        if (type2.equals(LTE) || type2.equals(UMB) || type2.equals(HSPA_PLUS) || type2.equals("4g")) {
            return "4g";
        }
        return TYPE_UNKNOWN;
    }
}
