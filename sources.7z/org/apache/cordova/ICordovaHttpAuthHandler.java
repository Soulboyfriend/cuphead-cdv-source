package org.apache.cordova;

public interface ICordovaHttpAuthHandler {
    void cancel();

    void proceed(String str, String str2);
}
