package org.apache.cordova;

public final class R {
    private R() {
    }
}
