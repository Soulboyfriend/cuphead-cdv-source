package org.apache.cordova.file;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.cordova.CordovaResourceApi;
import org.json.JSONException;
import org.json.JSONObject;

public class ContentFilesystem extends Filesystem {
    private final Context context;

    public ContentFilesystem(Context context2, CordovaResourceApi resourceApi) {
        super(Uri.parse("content://"), "content", resourceApi);
        this.context = context2;
    }

    public Uri toNativeUri(LocalFilesystemURL inputURL) {
        String authorityAndPath = inputURL.uri.getEncodedPath().substring(this.name.length() + 2);
        if (authorityAndPath.length() < 2) {
            return null;
        }
        String ret = "content://" + authorityAndPath;
        String query = inputURL.uri.getEncodedQuery();
        if (query != null) {
            ret = ret + '?' + query;
        }
        String frag = inputURL.uri.getEncodedFragment();
        if (frag != null) {
            ret = ret + '#' + frag;
        }
        return Uri.parse(ret);
    }

    public LocalFilesystemURL toLocalUri(Uri inputURL) {
        if (!"content".equals(inputURL.getScheme())) {
            return null;
        }
        String subPath = inputURL.getEncodedPath();
        if (subPath.length() > 0) {
            subPath = subPath.substring(1);
        }
        Uri.Builder b = new Uri.Builder().scheme(LocalFilesystemURL.FILESYSTEM_PROTOCOL).authority("localhost").path(this.name).appendPath(inputURL.getAuthority());
        if (subPath.length() > 0) {
            b.appendEncodedPath(subPath);
        }
        return LocalFilesystemURL.parse(b.encodedQuery(inputURL.getEncodedQuery()).encodedFragment(inputURL.getEncodedFragment()).build());
    }

    public JSONObject getFileForLocalURL(LocalFilesystemURL inputURL, String fileName, JSONObject options, boolean directory) throws IOException, TypeMismatchException, JSONException {
        throw new UnsupportedOperationException("getFile() not supported for content:. Use resolveLocalFileSystemURL instead.");
    }

    public boolean removeFileAtLocalURL(LocalFilesystemURL inputURL) throws NoModificationAllowedException {
        Uri contentUri = toNativeUri(inputURL);
        try {
            this.context.getContentResolver().delete(contentUri, (String) null, (String[]) null);
            return true;
        } catch (UnsupportedOperationException t) {
            NoModificationAllowedException nmae = new NoModificationAllowedException("Deleting not supported for content uri: " + contentUri);
            nmae.initCause(t);
            throw nmae;
        }
    }

    public boolean recursiveRemoveFileAtLocalURL(LocalFilesystemURL inputURL) throws NoModificationAllowedException {
        throw new NoModificationAllowedException("Cannot remove content url");
    }

    public LocalFilesystemURL[] listChildren(LocalFilesystemURL inputURL) throws FileNotFoundException {
        throw new UnsupportedOperationException("readEntriesAtLocalURL() not supported for content:. Use resolveLocalFileSystemURL instead.");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x003c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public org.json.JSONObject getFileMetadataForLocalURL(org.apache.cordova.file.LocalFilesystemURL r12) throws java.io.FileNotFoundException {
        /*
            r11 = this;
            r0 = -1
            r2 = 0
            android.net.Uri r4 = r11.toNativeUri(r12)
            org.apache.cordova.CordovaResourceApi r5 = r11.resourceApi
            java.lang.String r5 = r5.getMimeType(r4)
            android.database.Cursor r6 = r11.openCursorForURL(r4)
            if (r6 == 0) goto L_0x0031
            boolean r7 = r6.moveToFirst()     // Catch:{ IOException -> 0x0068 }
            if (r7 == 0) goto L_0x0031
            java.lang.Long r7 = r11.resourceSizeForCursor(r6)     // Catch:{ IOException -> 0x0068 }
            if (r7 == 0) goto L_0x0025
            long r8 = r7.longValue()     // Catch:{ IOException -> 0x0068 }
            r0 = r8
        L_0x0025:
            java.lang.Long r8 = r11.lastModifiedDateForCursor(r6)     // Catch:{ IOException -> 0x0068 }
            if (r8 == 0) goto L_0x0030
            long r9 = r8.longValue()     // Catch:{ IOException -> 0x0068 }
            r2 = r9
        L_0x0030:
            goto L_0x003a
        L_0x0031:
            org.apache.cordova.CordovaResourceApi r7 = r11.resourceApi     // Catch:{ IOException -> 0x0068 }
            org.apache.cordova.CordovaResourceApi$OpenForReadResult r7 = r7.openForRead(r4)     // Catch:{ IOException -> 0x0068 }
            long r8 = r7.length     // Catch:{ IOException -> 0x0068 }
            r0 = r8
        L_0x003a:
            if (r6 == 0) goto L_0x003f
            r6.close()
        L_0x003f:
            org.json.JSONObject r7 = new org.json.JSONObject
            r7.<init>()
            java.lang.String r8 = "size"
            r7.put(r8, r0)     // Catch:{ JSONException -> 0x0063 }
            java.lang.String r8 = "type"
            r7.put(r8, r5)     // Catch:{ JSONException -> 0x0063 }
            java.lang.String r8 = "name"
            java.lang.String r9 = r11.name     // Catch:{ JSONException -> 0x0063 }
            r7.put(r8, r9)     // Catch:{ JSONException -> 0x0063 }
            java.lang.String r8 = "fullPath"
            java.lang.String r9 = r12.path     // Catch:{ JSONException -> 0x0063 }
            r7.put(r8, r9)     // Catch:{ JSONException -> 0x0063 }
            java.lang.String r8 = "lastModifiedDate"
            r7.put(r8, r2)     // Catch:{ JSONException -> 0x0063 }
            return r7
        L_0x0063:
            r8 = move-exception
            r9 = 0
            return r9
        L_0x0066:
            r7 = move-exception
            goto L_0x0073
        L_0x0068:
            r7 = move-exception
            java.io.FileNotFoundException r8 = new java.io.FileNotFoundException     // Catch:{ all -> 0x0066 }
            r8.<init>()     // Catch:{ all -> 0x0066 }
            r8.initCause(r7)     // Catch:{ all -> 0x0066 }
            throw r8     // Catch:{ all -> 0x0066 }
        L_0x0073:
            if (r6 == 0) goto L_0x0078
            r6.close()
        L_0x0078:
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.file.ContentFilesystem.getFileMetadataForLocalURL(org.apache.cordova.file.LocalFilesystemURL):org.json.JSONObject");
    }

    public long writeToFileAtURL(LocalFilesystemURL inputURL, String data, int offset, boolean isBinary) throws NoModificationAllowedException {
        throw new NoModificationAllowedException("Couldn't write to file given its content URI");
    }

    public long truncateFileAtURL(LocalFilesystemURL inputURL, long size) throws NoModificationAllowedException {
        throw new NoModificationAllowedException("Couldn't truncate file given its content URI");
    }

    /* access modifiers changed from: protected */
    public Cursor openCursorForURL(Uri nativeUri) {
        try {
            return this.context.getContentResolver().query(nativeUri, (String[]) null, (String) null, (String[]) null, (String) null);
        } catch (UnsupportedOperationException e) {
            return null;
        }
    }

    private Long resourceSizeForCursor(Cursor cursor) {
        String sizeStr;
        int columnIndex = cursor.getColumnIndex("_size");
        if (columnIndex == -1 || (sizeStr = cursor.getString(columnIndex)) == null) {
            return null;
        }
        return Long.valueOf(Long.parseLong(sizeStr));
    }

    /* access modifiers changed from: protected */
    public Long lastModifiedDateForCursor(Cursor cursor) {
        String dateStr;
        int columnIndex = cursor.getColumnIndex("date_modified");
        if (columnIndex == -1) {
            columnIndex = cursor.getColumnIndex("last_modified");
        }
        if (columnIndex == -1 || (dateStr = cursor.getString(columnIndex)) == null) {
            return null;
        }
        return Long.valueOf(Long.parseLong(dateStr));
    }

    public String filesystemPathForURL(LocalFilesystemURL url) {
        File f = this.resourceApi.mapUriToFile(toNativeUri(url));
        if (f == null) {
            return null;
        }
        return f.getAbsolutePath();
    }

    public LocalFilesystemURL URLforFilesystemPath(String path) {
        return null;
    }

    public boolean canRemoveFileAtLocalURL(LocalFilesystemURL inputURL) {
        return true;
    }
}
