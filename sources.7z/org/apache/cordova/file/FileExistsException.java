package org.apache.cordova.file;

public class FileExistsException extends Exception {
    public FileExistsException(String msg) {
        super(msg);
    }
}
