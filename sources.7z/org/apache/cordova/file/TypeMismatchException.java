package org.apache.cordova.file;

public class TypeMismatchException extends Exception {
    public TypeMismatchException(String message) {
        super(message);
    }
}
