package org.apache.cordova.file;

public class NoModificationAllowedException extends Exception {
    public NoModificationAllowedException(String message) {
        super(message);
    }
}
