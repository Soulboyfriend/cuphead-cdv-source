package org.apache.cordova;

import android.webkit.ValueCallback;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import org.apache.cordova.PluginResult;

public class NativeToJsMessageQueue {
    private static int COMBINED_RESPONSE_CUTOFF = 16777216;
    static final boolean DISABLE_EXEC_CHAINING = false;
    private static final boolean FORCE_ENCODE_USING_EVAL = false;
    private static final String LOG_TAG = "JsMessageQueue";
    private BridgeMode activeBridgeMode;
    private ArrayList<BridgeMode> bridgeModes = new ArrayList<>();
    private boolean paused;
    private final LinkedList<JsMessage> queue = new LinkedList<>();

    public void addBridgeMode(BridgeMode bridgeMode) {
        this.bridgeModes.add(bridgeMode);
    }

    public boolean isBridgeEnabled() {
        return this.activeBridgeMode != null;
    }

    public boolean isEmpty() {
        return this.queue.isEmpty();
    }

    public void setBridgeMode(int value) {
        if (value < -1 || value >= this.bridgeModes.size()) {
            LOG.d(LOG_TAG, "Invalid NativeToJsBridgeMode: " + value);
            return;
        }
        BridgeMode newMode = value < 0 ? null : this.bridgeModes.get(value);
        if (newMode != this.activeBridgeMode) {
            StringBuilder sb = new StringBuilder();
            sb.append("Set native->JS mode to ");
            sb.append(newMode == null ? "null" : newMode.getClass().getSimpleName());
            LOG.d(LOG_TAG, sb.toString());
            synchronized (this) {
                this.activeBridgeMode = newMode;
                if (newMode != null) {
                    newMode.reset();
                    if (!this.paused && !this.queue.isEmpty()) {
                        newMode.onNativeToJsMessageAvailable(this);
                    }
                }
            }
        }
    }

    public void reset() {
        synchronized (this) {
            this.queue.clear();
            setBridgeMode(-1);
        }
    }

    private int calculatePackedMessageLength(JsMessage message) {
        int messageLen = message.calculateEncodedLength();
        return String.valueOf(messageLen).length() + messageLen + 1;
    }

    private void packMessage(JsMessage message, StringBuilder sb) {
        sb.append(message.calculateEncodedLength());
        sb.append(' ');
        message.encodeAsMessage(sb);
    }

    public String popAndEncode(boolean fromOnlineEvent) {
        synchronized (this) {
            if (this.activeBridgeMode == null) {
                return null;
            }
            this.activeBridgeMode.notifyOfFlush(this, fromOnlineEvent);
            if (this.queue.isEmpty()) {
                return null;
            }
            int totalPayloadLen = 0;
            int numMessagesToSend = 0;
            Iterator it = this.queue.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                int messageSize = calculatePackedMessageLength((JsMessage) it.next());
                if (numMessagesToSend > 0 && COMBINED_RESPONSE_CUTOFF > 0 && totalPayloadLen + messageSize > COMBINED_RESPONSE_CUTOFF) {
                    break;
                }
                totalPayloadLen += messageSize;
                numMessagesToSend++;
            }
            StringBuilder sb = new StringBuilder(totalPayloadLen);
            for (int i = 0; i < numMessagesToSend; i++) {
                packMessage(this.queue.removeFirst(), sb);
            }
            if (!this.queue.isEmpty()) {
                sb.append('*');
            }
            String ret = sb.toString();
            return ret;
        }
    }

    public String popAndEncodeAsJs() {
        synchronized (this) {
            if (this.queue.size() == 0) {
                return null;
            }
            int totalPayloadLen = 0;
            int numMessagesToSend = 0;
            Iterator it = this.queue.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                int messageSize = ((JsMessage) it.next()).calculateEncodedLength() + 50;
                if (numMessagesToSend > 0 && COMBINED_RESPONSE_CUTOFF > 0 && totalPayloadLen + messageSize > COMBINED_RESPONSE_CUTOFF) {
                    break;
                }
                totalPayloadLen += messageSize;
                numMessagesToSend++;
            }
            int i = 0;
            boolean willSendAllMessages = numMessagesToSend == this.queue.size();
            StringBuilder sb = new StringBuilder((willSendAllMessages ? 0 : 100) + totalPayloadLen);
            for (int i2 = 0; i2 < numMessagesToSend; i2++) {
                JsMessage message = this.queue.removeFirst();
                if (!willSendAllMessages || i2 + 1 != numMessagesToSend) {
                    sb.append("try{");
                    message.encodeAsJsMessage(sb);
                    sb.append("}finally{");
                } else {
                    message.encodeAsJsMessage(sb);
                }
            }
            if (!willSendAllMessages) {
                sb.append("window.setTimeout(function(){cordova.require('cordova/plugin/android/polling').pollOnce();},0);");
            }
            if (willSendAllMessages) {
                i = 1;
            }
            while (i < numMessagesToSend) {
                sb.append('}');
                i++;
            }
            String ret = sb.toString();
            return ret;
        }
    }

    public void addJavaScript(String statement) {
        enqueueMessage(new JsMessage(statement));
    }

    public void addPluginResult(PluginResult result, String callbackId) {
        if (callbackId == null) {
            LOG.e(LOG_TAG, "Got plugin result with no callbackId", new Throwable());
            return;
        }
        boolean noResult = result.getStatus() == PluginResult.Status.NO_RESULT.ordinal();
        boolean keepCallback = result.getKeepCallback();
        if (!noResult || !keepCallback) {
            enqueueMessage(new JsMessage(result, callbackId));
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x001d, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void enqueueMessage(org.apache.cordova.NativeToJsMessageQueue.JsMessage r3) {
        /*
            r2 = this;
            monitor-enter(r2)
            org.apache.cordova.NativeToJsMessageQueue$BridgeMode r0 = r2.activeBridgeMode     // Catch:{ all -> 0x001e }
            if (r0 != 0) goto L_0x000e
            java.lang.String r0 = "JsMessageQueue"
            java.lang.String r1 = "Dropping Native->JS message due to disabled bridge"
            org.apache.cordova.LOG.d(r0, r1)     // Catch:{ all -> 0x001e }
            monitor-exit(r2)     // Catch:{ all -> 0x001e }
            return
        L_0x000e:
            java.util.LinkedList<org.apache.cordova.NativeToJsMessageQueue$JsMessage> r0 = r2.queue     // Catch:{ all -> 0x001e }
            r0.add(r3)     // Catch:{ all -> 0x001e }
            boolean r0 = r2.paused     // Catch:{ all -> 0x001e }
            if (r0 != 0) goto L_0x001c
            org.apache.cordova.NativeToJsMessageQueue$BridgeMode r0 = r2.activeBridgeMode     // Catch:{ all -> 0x001e }
            r0.onNativeToJsMessageAvailable(r2)     // Catch:{ all -> 0x001e }
        L_0x001c:
            monitor-exit(r2)     // Catch:{ all -> 0x001e }
            return
        L_0x001e:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x001e }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.apache.cordova.NativeToJsMessageQueue.enqueueMessage(org.apache.cordova.NativeToJsMessageQueue$JsMessage):void");
    }

    public void setPaused(boolean value) {
        if (this.paused && value) {
            LOG.e(LOG_TAG, "nested call to setPaused detected.", new Throwable());
        }
        this.paused = value;
        if (!value) {
            synchronized (this) {
                if (!this.queue.isEmpty() && this.activeBridgeMode != null) {
                    this.activeBridgeMode.onNativeToJsMessageAvailable(this);
                }
            }
        }
    }

    public static abstract class BridgeMode {
        public abstract void onNativeToJsMessageAvailable(NativeToJsMessageQueue nativeToJsMessageQueue);

        public void notifyOfFlush(NativeToJsMessageQueue queue, boolean fromOnlineEvent) {
        }

        public void reset() {
        }
    }

    public static class NoOpBridgeMode extends BridgeMode {
        public void onNativeToJsMessageAvailable(NativeToJsMessageQueue queue) {
        }
    }

    public static class LoadUrlBridgeMode extends BridgeMode {
        private final CordovaInterface cordova;
        /* access modifiers changed from: private */
        public final CordovaWebViewEngine engine;

        public LoadUrlBridgeMode(CordovaWebViewEngine engine2, CordovaInterface cordova2) {
            this.engine = engine2;
            this.cordova = cordova2;
        }

        public void onNativeToJsMessageAvailable(final NativeToJsMessageQueue queue) {
            this.cordova.getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    String js = queue.popAndEncodeAsJs();
                    if (js != null) {
                        CordovaWebViewEngine access$000 = LoadUrlBridgeMode.this.engine;
                        access$000.loadUrl("javascript:" + js, false);
                    }
                }
            });
        }
    }

    public static class OnlineEventsBridgeMode extends BridgeMode {
        /* access modifiers changed from: private */
        public final OnlineEventsBridgeModeDelegate delegate;
        /* access modifiers changed from: private */
        public boolean ignoreNextFlush;
        /* access modifiers changed from: private */
        public boolean online;

        public interface OnlineEventsBridgeModeDelegate {
            void runOnUiThread(Runnable runnable);

            void setNetworkAvailable(boolean z);
        }

        public OnlineEventsBridgeMode(OnlineEventsBridgeModeDelegate delegate2) {
            this.delegate = delegate2;
        }

        public void reset() {
            this.delegate.runOnUiThread(new Runnable() {
                public void run() {
                    boolean unused = OnlineEventsBridgeMode.this.online = false;
                    boolean unused2 = OnlineEventsBridgeMode.this.ignoreNextFlush = true;
                    OnlineEventsBridgeMode.this.delegate.setNetworkAvailable(true);
                }
            });
        }

        public void onNativeToJsMessageAvailable(final NativeToJsMessageQueue queue) {
            this.delegate.runOnUiThread(new Runnable() {
                public void run() {
                    if (!queue.isEmpty()) {
                        boolean unused = OnlineEventsBridgeMode.this.ignoreNextFlush = false;
                        OnlineEventsBridgeMode.this.delegate.setNetworkAvailable(OnlineEventsBridgeMode.this.online);
                    }
                }
            });
        }

        public void notifyOfFlush(NativeToJsMessageQueue queue, boolean fromOnlineEvent) {
            if (fromOnlineEvent && !this.ignoreNextFlush) {
                this.online = !this.online;
            }
        }
    }

    public static class EvalBridgeMode extends BridgeMode {
        private final CordovaInterface cordova;
        /* access modifiers changed from: private */
        public final CordovaWebViewEngine engine;

        public EvalBridgeMode(CordovaWebViewEngine engine2, CordovaInterface cordova2) {
            this.engine = engine2;
            this.cordova = cordova2;
        }

        public void onNativeToJsMessageAvailable(final NativeToJsMessageQueue queue) {
            this.cordova.getActivity().runOnUiThread(new Runnable() {
                public void run() {
                    String js = queue.popAndEncodeAsJs();
                    if (js != null) {
                        EvalBridgeMode.this.engine.evaluateJavascript(js, (ValueCallback<String>) null);
                    }
                }
            });
        }
    }

    private static class JsMessage {
        final String jsPayloadOrCallbackId;
        final PluginResult pluginResult;

        JsMessage(String js) {
            if (js != null) {
                this.jsPayloadOrCallbackId = js;
                this.pluginResult = null;
                return;
            }
            throw null;
        }

        JsMessage(PluginResult pluginResult2, String callbackId) {
            if (callbackId == null || pluginResult2 == null) {
                throw null;
            }
            this.jsPayloadOrCallbackId = callbackId;
            this.pluginResult = pluginResult2;
        }

        static int calculateEncodedLengthHelper(PluginResult pluginResult2) {
            switch (pluginResult2.getMessageType()) {
                case 1:
                    return pluginResult2.getStrMessage().length() + 1;
                case 3:
                    return pluginResult2.getMessage().length() + 1;
                case 4:
                case 5:
                    return 1;
                case 6:
                    return pluginResult2.getMessage().length() + 1;
                case 7:
                    return pluginResult2.getMessage().length() + 1;
                case PluginResult.MESSAGE_TYPE_MULTIPART /*8*/:
                    int ret = 1;
                    for (int i = 0; i < pluginResult2.getMultipartMessagesSize(); i++) {
                        int length = calculateEncodedLengthHelper(pluginResult2.getMultipartMessage(i));
                        ret += String.valueOf(length).length() + 1 + length;
                    }
                    return ret;
                default:
                    return pluginResult2.getMessage().length();
            }
        }

        /* access modifiers changed from: package-private */
        public int calculateEncodedLength() {
            PluginResult pluginResult2 = this.pluginResult;
            if (pluginResult2 == null) {
                return this.jsPayloadOrCallbackId.length() + 1;
            }
            return calculateEncodedLengthHelper(this.pluginResult) + String.valueOf(pluginResult2.getStatus()).length() + 2 + 1 + this.jsPayloadOrCallbackId.length() + 1;
        }

        static void encodeAsMessageHelper(StringBuilder sb, PluginResult pluginResult2) {
            switch (pluginResult2.getMessageType()) {
                case 1:
                    sb.append('s');
                    sb.append(pluginResult2.getStrMessage());
                    return;
                case 3:
                    sb.append('n');
                    sb.append(pluginResult2.getMessage());
                    return;
                case 4:
                    sb.append(pluginResult2.getMessage().charAt(0));
                    return;
                case 5:
                    sb.append('N');
                    return;
                case 6:
                    sb.append('A');
                    sb.append(pluginResult2.getMessage());
                    return;
                case 7:
                    sb.append('S');
                    sb.append(pluginResult2.getMessage());
                    return;
                case PluginResult.MESSAGE_TYPE_MULTIPART /*8*/:
                    sb.append('M');
                    for (int i = 0; i < pluginResult2.getMultipartMessagesSize(); i++) {
                        PluginResult multipartMessage = pluginResult2.getMultipartMessage(i);
                        sb.append(String.valueOf(calculateEncodedLengthHelper(multipartMessage)));
                        sb.append(' ');
                        encodeAsMessageHelper(sb, multipartMessage);
                    }
                    return;
                default:
                    sb.append(pluginResult2.getMessage());
                    return;
            }
        }

        /* access modifiers changed from: package-private */
        public void encodeAsMessage(StringBuilder sb) {
            PluginResult pluginResult2 = this.pluginResult;
            if (pluginResult2 == null) {
                sb.append('J');
                sb.append(this.jsPayloadOrCallbackId);
                return;
            }
            int status = pluginResult2.getStatus();
            boolean resultOk = true;
            boolean noResult = status == PluginResult.Status.NO_RESULT.ordinal();
            if (status != PluginResult.Status.OK.ordinal()) {
                resultOk = false;
            }
            boolean keepCallback = this.pluginResult.getKeepCallback();
            sb.append((noResult || resultOk) ? 'S' : 'F');
            sb.append(keepCallback ? '1' : '0');
            sb.append(status);
            sb.append(' ');
            sb.append(this.jsPayloadOrCallbackId);
            sb.append(' ');
            encodeAsMessageHelper(sb, this.pluginResult);
        }

        /* access modifiers changed from: package-private */
        public void buildJsMessage(StringBuilder sb) {
            int messageType = this.pluginResult.getMessageType();
            if (messageType == 5) {
                sb.append("null");
            } else if (messageType == 6) {
                sb.append("cordova.require('cordova/base64').toArrayBuffer('");
                sb.append(this.pluginResult.getMessage());
                sb.append("')");
            } else if (messageType == 7) {
                sb.append("atob('");
                sb.append(this.pluginResult.getMessage());
                sb.append("')");
            } else if (messageType != 8) {
                sb.append(this.pluginResult.getMessage());
            } else {
                int size = this.pluginResult.getMultipartMessagesSize();
                for (int i = 0; i < size; i++) {
                    new JsMessage(this.pluginResult.getMultipartMessage(i), this.jsPayloadOrCallbackId).buildJsMessage(sb);
                    if (i < size - 1) {
                        sb.append(",");
                    }
                }
            }
        }

        /* access modifiers changed from: package-private */
        public void encodeAsJsMessage(StringBuilder sb) {
            PluginResult pluginResult2 = this.pluginResult;
            if (pluginResult2 == null) {
                sb.append(this.jsPayloadOrCallbackId);
                return;
            }
            int status = pluginResult2.getStatus();
            boolean success = status == PluginResult.Status.OK.ordinal() || status == PluginResult.Status.NO_RESULT.ordinal();
            sb.append("cordova.callbackFromNative('");
            sb.append(this.jsPayloadOrCallbackId);
            sb.append("',");
            sb.append(success);
            sb.append(",");
            sb.append(status);
            sb.append(",[");
            buildJsMessage(sb);
            sb.append("],");
            sb.append(this.pluginResult.getKeepCallback());
            sb.append(");");
        }
    }
}
