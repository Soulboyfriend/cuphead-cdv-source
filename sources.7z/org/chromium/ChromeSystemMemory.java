package org.chromium;

import android.app.ActivityManager;
import android.os.Build;
import android.util.Log;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaArgs;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.json.JSONException;
import org.json.JSONObject;

public class ChromeSystemMemory extends CordovaPlugin {
    private static final String LOG_TAG = "ChromeSystemMemory";
    /* access modifiers changed from: private */
    public ActivityManager activityManager;

    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.activityManager = (ActivityManager) cordova.getActivity().getSystemService("activity");
    }

    public boolean execute(String action, CordovaArgs args, CallbackContext callbackContext) throws JSONException {
        if (!"getInfo".equals(action)) {
            return false;
        }
        getInfo(args, callbackContext);
        return true;
    }

    private void getInfo(CordovaArgs args, final CallbackContext callbackContext) {
        this.cordova.getThreadPool().execute(new Runnable() {
            public void run() {
                try {
                    JSONObject ret = new JSONObject();
                    ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
                    ChromeSystemMemory.this.activityManager.getMemoryInfo(memoryInfo);
                    ret.put("availableCapacity", memoryInfo.availMem);
                    if (Build.VERSION.SDK_INT >= 16) {
                        ret.put("capacity", memoryInfo.totalMem);
                    }
                    callbackContext.success(ret);
                } catch (Exception e) {
                    Log.e(ChromeSystemMemory.LOG_TAG, "Error occured while getting memory info", e);
                    callbackContext.error("Could not get memory info");
                }
            }
        });
    }
}
