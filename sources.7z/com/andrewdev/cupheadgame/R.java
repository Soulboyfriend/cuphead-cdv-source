package com.andrewdev.cupheadgame;

public final class R {

    public static final class drawable {
        public static final int screen = 2130771968;

        private drawable() {
        }
    }

    public static final class mipmap {
        public static final int ic_launcher = 2130837504;
        public static final int ic_launcher_background = 2130837505;
        public static final int ic_launcher_foreground = 2130837506;

        private mipmap() {
        }
    }

    public static final class string {
        public static final int activity_name = 2130903040;
        public static final int app_name = 2130903041;
        public static final int launcher_name = 2130903042;

        private string() {
        }
    }

    public static final class xml {
        public static final int config = 2130968576;

        private xml() {
        }
    }

    private R() {
    }
}
