package com.android.plugins;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Permissions extends CordovaPlugin {
    private static final String ACTION_CHECK_PERMISSION = "checkPermission";
    private static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    private static final String ACTION_REQUEST_PERMISSION = "requestPermission";
    private static final String ACTION_REQUEST_PERMISSIONS = "requestPermissions";
    private static final String KEY_ERROR = "error";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_RESULT_PERMISSION = "hasPermission";
    private static final int REQUEST_CODE_ENABLE_PERMISSION = 55433;
    private static String TAG = "Permissions";
    /* access modifiers changed from: private */
    public CallbackContext permissionsCallback;

    public boolean execute(String action, final JSONArray args, final CallbackContext callbackContext) throws JSONException {
        if (ACTION_CHECK_PERMISSION.equals(action)) {
            this.cordova.getThreadPool().execute(new Runnable() {
                public void run() {
                    Permissions.this.checkPermissionAction(callbackContext, args);
                }
            });
            return true;
        } else if (!ACTION_REQUEST_PERMISSION.equals(action) && !ACTION_REQUEST_PERMISSIONS.equals(action)) {
            return false;
        } else {
            this.cordova.getThreadPool().execute(new Runnable() {
                public void run() {
                    try {
                        Permissions.this.requestPermissionAction(callbackContext, args);
                    } catch (Exception e) {
                        e.printStackTrace();
                        JSONObject returnObj = new JSONObject();
                        Permissions.this.addProperty(returnObj, Permissions.KEY_ERROR, Permissions.ACTION_REQUEST_PERMISSION);
                        Permissions.this.addProperty(returnObj, Permissions.KEY_MESSAGE, "Request permission has been denied.");
                        callbackContext.error(returnObj);
                        CallbackContext unused = Permissions.this.permissionsCallback = null;
                    }
                }
            });
            return true;
        }
    }

    public void onRequestPermissionResult(int requestCode, String[] permissions, int[] grantResults) throws JSONException {
        if (this.permissionsCallback != null) {
            JSONObject returnObj = new JSONObject();
            if (permissions == null || permissions.length <= 0) {
                addProperty(returnObj, KEY_ERROR, ACTION_REQUEST_PERMISSION);
                addProperty(returnObj, KEY_MESSAGE, "Unknown error.");
                this.permissionsCallback.error(returnObj);
            } else {
                addProperty(returnObj, KEY_RESULT_PERMISSION, Boolean.valueOf(hasAllPermissions(permissions)));
                this.permissionsCallback.success(returnObj);
            }
            this.permissionsCallback = null;
        }
    }

    /* access modifiers changed from: private */
    public void checkPermissionAction(CallbackContext callbackContext, JSONArray permission) {
        if (permission == null || permission.length() == 0 || permission.length() > 1) {
            JSONObject returnObj = new JSONObject();
            addProperty(returnObj, KEY_ERROR, ACTION_CHECK_PERMISSION);
            addProperty(returnObj, KEY_MESSAGE, "One time one permission only.");
            callbackContext.error(returnObj);
        } else if (Build.VERSION.SDK_INT < 23) {
            JSONObject returnObj2 = new JSONObject();
            addProperty(returnObj2, KEY_RESULT_PERMISSION, true);
            callbackContext.success(returnObj2);
        } else {
            try {
                String permission0 = permission.getString(0);
                JSONObject returnObj3 = new JSONObject();
                if ("android.permission.SYSTEM_ALERT_WINDOW".equals(permission0)) {
                    addProperty(returnObj3, KEY_RESULT_PERMISSION, Boolean.valueOf(Settings.canDrawOverlays(this.cordova.getActivity().getApplicationContext())));
                } else {
                    addProperty(returnObj3, KEY_RESULT_PERMISSION, Boolean.valueOf(this.cordova.hasPermission(permission0)));
                }
                callbackContext.success(returnObj3);
            } catch (JSONException ex) {
                JSONObject returnObj4 = new JSONObject();
                addProperty(returnObj4, KEY_ERROR, ACTION_REQUEST_PERMISSION);
                addProperty(returnObj4, KEY_MESSAGE, "Check permission has been failed." + ex);
                callbackContext.error(returnObj4);
            }
        }
    }

    /* access modifiers changed from: private */
    public void requestPermissionAction(CallbackContext callbackContext, JSONArray permissions) throws Exception {
        if (permissions == null || permissions.length() == 0) {
            JSONObject returnObj = new JSONObject();
            addProperty(returnObj, KEY_ERROR, ACTION_REQUEST_PERMISSION);
            addProperty(returnObj, KEY_MESSAGE, "At least one permission.");
            callbackContext.error(returnObj);
        } else if (Build.VERSION.SDK_INT < 23) {
            JSONObject returnObj2 = new JSONObject();
            addProperty(returnObj2, KEY_RESULT_PERMISSION, true);
            callbackContext.success(returnObj2);
        } else if (hasAllPermissions(permissions)) {
            JSONObject returnObj3 = new JSONObject();
            addProperty(returnObj3, KEY_RESULT_PERMISSION, true);
            callbackContext.success(returnObj3);
        } else {
            this.permissionsCallback = callbackContext;
            String[] permissionArray = getPermissions(permissions);
            if (permissionArray.length == 1 && "android.permission.SYSTEM_ALERT_WINDOW".equals(permissionArray[0])) {
                Log.i(TAG, "Request permission SYSTEM_ALERT_WINDOW");
                Activity activity = this.cordova.getActivity();
                if (!Settings.canDrawOverlays(this.cordova.getActivity().getApplicationContext())) {
                    Log.w(TAG, "Request permission SYSTEM_ALERT_WINDOW start intent because canDrawOverlays=false");
                    activity.startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + activity.getPackageName())), ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
                    return;
                }
            }
            this.cordova.requestPermissions(this, REQUEST_CODE_ENABLE_PERMISSION, permissionArray);
        }
    }

    private String[] getPermissions(JSONArray permissions) {
        String[] stringArray = new String[permissions.length()];
        for (int i = 0; i < permissions.length(); i++) {
            try {
                stringArray[i] = permissions.getString(i);
            } catch (JSONException e) {
            }
        }
        return stringArray;
    }

    private boolean hasAllPermissions(JSONArray permissions) throws JSONException {
        return hasAllPermissions(getPermissions(permissions));
    }

    private boolean hasAllPermissions(String[] permissions) throws JSONException {
        for (String permission : permissions) {
            if (!this.cordova.hasPermission(permission)) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: private */
    public void addProperty(JSONObject obj, String key, Object value) {
        if (value == null) {
            try {
                obj.put(key, JSONObject.NULL);
            } catch (JSONException e) {
            }
        } else {
            obj.put(key, value);
        }
    }
}
